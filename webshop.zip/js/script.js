let cart = [];

function addToCart(name, price) {
  cart.push({ name, price });
  localStorage.setItem("cart", JSON.stringify(cart));
  alert(name + " u shtua në karrocë!");
}

window.onload = function () {
  const items = JSON.parse(localStorage.getItem("cart")) || [];
  let total = 0;
  const cartItems = document.getElementById("cart-items");

  if (cartItems) {
    items.forEach(item => {
      const li = document.createElement("li");
      li.innerText = `${item.name} - ${item.price} Lek`;
      cartItems.appendChild(li);
      total += item.price;
    });

    document.getElementById("total").innerText = total;
  }
};
